@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://producer.soap.camel.lespinel.com/")
package com.lespinel.camel.soap.producer;
